/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaAjedrezInicial;

/**
 * Preparando el infierno de la IA. La idea de la que parto (que no tiene porque ser la única y final). Es que haré
 * una especie de algoritmo donde iré buscando la mejor jugada. Para ello necesitaré evaluar muchos tableros y tenerlos
 * "ordenados" en el tiempo. Es un trabajo extenso y que dejaré medio con chinchetas porque si no no acabo el proyecto nunca
 * pero puede ser un ejemplo de como ir poniendo una IA bastante tonta.
 * @author Luis
 */
class AnalisisBoard {
    
    
    
}
