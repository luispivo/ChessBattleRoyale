/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaAjedrezInicial;

/**
 * Colores de los 4 jugadores del juego
 * @author Luis
 */
enum Color{
    BLACK,BLUE,PURPLE,GREEN
}
