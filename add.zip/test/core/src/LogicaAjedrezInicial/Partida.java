/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaAjedrezInicial;

import java.util.ArrayList;

/**
 * Clase para tener seteados todas las cosas de la partida
 * @author Luis
 */
class Partida {
    ArrayList<Jugador> JugadoresActivos;
    
    
}
